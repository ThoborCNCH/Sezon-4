package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.DirLF;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.DirLR;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.DirRF;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.DirRR;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_dpad;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_rotire;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorInchis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorDeschis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAbsorbtie;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAruncare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciInchis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciDeschis;


/**
 * This file contains an minimal example of a Linear "OpMode". An OpMode is a 'program' that runs in either
 * the autonomous or the teleop period of an FTC match. The names of OpModes appear on the menu
 * of the FTC Driver Station. When an selection is made from the menu, the corresponding OpMode
 * class is instantiated on the Robot Controller and executed.
 * <p>
 * This particular OpMode just executes a basic Tank Drive Teleop for a two wheeled robot
 * It includes all the skeletal structure that all linear OpModes contain.
 * <p>
 * Use Android Studios to Copy this Class, and Paste it into your team's code folder with a new name.
 * Remove or comment out the @Disabled line to add this opmode to the Driver Station OpMode list
 */
@Disabled

@TeleOp(name = "TeleOP BUN", group = "TeleOP")
//@Disabled
public class TeleOP_BUN extends LinearOpMode {

    // Declare OpMode members.
    private DcMotor lf = null;
    private DcMotor rf = null;
    private DcMotor lr = null;
    private DcMotor rr = null;

    private DcMotor absorbtie = null;
    private DcMotor aruncare = null;

    private Servo tragaci = null;

    public Servo organizator = null;

    public double tragaciPus = 0;
    public double organizatorPus = 0;
    double buttonReleased = 1;
    double buttonReleased2 = 1;

    double v1, v2, v3, v4;


    @Override
    public void runOpMode() {

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());

        lf = hardwareMap.get(DcMotor.class, "front_left_motor");
        rf = hardwareMap.get(DcMotor.class, "front_right_motor");
        lr = hardwareMap.get(DcMotor.class, "back_left_motor");
        rr = hardwareMap.get(DcMotor.class, "back_right_motor");

        absorbtie = hardwareMap.get(DcMotor.class, "absorbtie");
        aruncare = hardwareMap.get(DcMotor.class, "aruncare");

        tragaci = hardwareMap.get(Servo.class, "tragaci");

        organizator = hardwareMap.get(Servo.class, "organizator");

        if (DirLR == 1) lr.setDirection(DcMotorSimple.Direction.FORWARD);
        else lr.setDirection(DcMotorSimple.Direction.REVERSE);
        if (DirRR == 1) rr.setDirection(DcMotorSimple.Direction.FORWARD);
        else rr.setDirection(DcMotorSimple.Direction.REVERSE);
        if (DirLF == 1) lf.setDirection(DcMotorSimple.Direction.FORWARD);
        else lf.setDirection(DcMotorSimple.Direction.REVERSE);
        if (DirRF == 1) rf.setDirection(DcMotorSimple.Direction.FORWARD);
        else rf.setDirection(DcMotorSimple.Direction.REVERSE);

        lf.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        lr.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rf.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rr.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);


        lf.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        lr.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rf.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rr.setMode(DcMotor.RunMode.RUN_USING_ENCODER);


        aruncare.setDirection(DcMotorSimple.Direction.REVERSE);


        telemetry.clearAll();
        telemetry.update();

//        waitForStart();
        AsteaptaStart();
        tragaci.setPosition(tragaciInchis);
        while (opModeIsActive()) {
            double r = Math.hypot(gamepad1.left_stick_x, -gamepad1.left_stick_y);
            double robotAngle = Math.atan2(-gamepad1.left_stick_y, gamepad1.left_stick_x) - Math.PI / 4;
            double rightX = (gamepad1.right_stick_x);
            v1 = r * Math.cos(robotAngle) + rightX;
            v2 = r * Math.sin(robotAngle) - rightX;
            v3 = r * Math.sin(robotAngle) + rightX;
            v4 = r * Math.cos(robotAngle) - rightX;

            double x = 1;
            if (gamepad1.dpad_down) {
                v1 = (-putere_dpad);
                v2 = (-putere_dpad);
                v3 = (-putere_dpad);
                v4 = (-putere_dpad);
            } else if (gamepad1.dpad_right) {
                v1 = (+putere_dpad);
                v2 = (-putere_dpad);
                v3 = (-putere_dpad);
                v4 = (putere_dpad);
            } else if (gamepad1.dpad_up) {
                v1 = (putere_dpad);
                v2 = (putere_dpad);
                v3 = (putere_dpad);
                v4 = (putere_dpad);
            } else if (gamepad1.dpad_left) {
                v1 = (-putere_dpad);
                v2 = (putere_dpad);
                v3 = (putere_dpad);
                v4 = (-putere_dpad);
            }
            lf.setPower(v1 * x);
            rf.setPower(v2 * x);
            lr.setPower(v3 * x);
            rr.setPower(v4 * x);
            int ok=1;
            while(gamepad1.left_trigger != 0 && ok ==1) {
                lf.setPower(-putere_rotire);
                rf.setPower(putere_rotire);
                lr.setPower(-putere_rotire);
                rr.setPower(putere_rotire);
                telemetry.addData("fr ", rf.getPower());
                telemetry.addData("rr ", rr.getPower());
                telemetry.addData("lf ", lf.getPower());
                telemetry.addData("lr ", lr.getPower());
                telemetry.update();
                if(gamepad1.left_trigger == 0){
                    ok=0;
                }
            }

            telemetry.addData("fr ", rf.getPower());
            telemetry.addData("rr ", rr.getPower());
            telemetry.addData("lf ", lf.getPower());
            telemetry.addData("lr ", lr.getPower());
            telemetry.update();
            
            int ok1 = 1;
            while(gamepad1.right_trigger != 0 && ok1 ==1) {
                lf.setPower(putere_rotire);
                rf.setPower(-putere_rotire);
                lr.setPower(putere_rotire);
                rr.setPower(-putere_rotire);
                if(gamepad1.right_trigger == 0){
                    ok1=0;
                }
            }



            if (gamepad1.left_bumper) {
                absorbtie.setPower(putereAbsorbtie);
            } else {
                absorbtie.setPower(0);
            }
            if (gamepad1.right_bumper) {
                aruncare.setPower(putereAruncare);
            } else {
                aruncare.setPower(0);
            }
            //----------[gheara]---------------------------------------------------------------------
            if (gamepad1.x && buttonReleased == 1) {
                buttonReleased = 0;
                if (tragaciPus == 0) {
                    tragaciPus = 1;
                    tragaci.setPosition(tragaciInchis);
                    telemetry.addLine("Tragaci s-a strans");


                } else {
                    tragaciPus = 0;
                    tragaci.setPosition(tragaciDeschis);
                    telemetry.addLine("Tragaci s-a deschis");
                }
            }
            if (!gamepad1.x) buttonReleased = 1;
            //----------[gheara]---------------------------------------------------------------------
            if (gamepad1.y && buttonReleased2 == 1) {
                buttonReleased2 = 0;
                if (organizatorPus == 0) {
                    organizatorPus = 1;
                    organizator.setPosition(organizatorInchis);
                    telemetry.addLine("Orgganizator s-a strans");


                } else {
                    organizatorPus = 0;
                    organizator.setPosition(organizatorDeschis);
                    telemetry.addLine("Organizator s-a deschis");
                }
            }
            if (!gamepad1.y) buttonReleased2 = 1;


            telemetry.update();
        }

    }
    public void AsteaptaStart()
    {
        while (!opModeIsActive() && !isStopRequested()) {

            telemetry.update();
        }
    }
}
  