# Ha' sa traiesti

Ha' sa traiesti

Aici sunt codurile Thobor RO068 - #17871

Team-Captain & Lead. of programming - Hanga Mihail

## Ce contine codul de anul asta?

Anul asta am reusit sa folosim RoadRunner (PIDF) pentru miscarea robotului, asadar avem miscari pe baza de coordonate, si nu numai, miscarile noastre fiind mult mai exacte acum.

Ne-am usurat munca folosind FTC Dashboard, unde putem modifica instant valori pentru teste, urmarirea robotului pe teren, telemetry pe laptop, camera stream pe laptop.

O varianta de folosire OpenCV camera, desi am ales sa folosim TenserFlow din singurul motiv ca parea mai eficient.

O automatizare a teleOp cu ajutorul RoadRunner.

-----       COMING SOON         -----


# Membrii echipei de programare din acest sezon:

Hanga Mihail

Dragutu Matei

Dragan Claudia

Grecu Andrei

