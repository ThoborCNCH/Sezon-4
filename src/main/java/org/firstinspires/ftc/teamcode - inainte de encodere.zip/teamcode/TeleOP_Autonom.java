package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.util.Angle;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_fata_dr;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_fata_st;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.full_power;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorDeschis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorInchis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.posAruncare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.posParcare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.pozitie_gheara_closed;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.pozitie_gheara_open;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAbsorbtie;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAruncare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereWooble;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_dpad;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_rotire;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciDeschis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciInchis;

@TeleOp(group = "Official")
public class TeleOP_Autonom extends LinearOpMode {

    public double tragaciPus = 0;
    public double organizatorPus = 0;
    public double fatetePuse = 0;
    public double ghearaPusa = 0;
    double buttonReleased = 1;
    double buttonReleased2 = 1;
    double buttonReleased3 = 1;
    double buttonReleased5 = 1;
    boolean right = true;


    double v1, v2, v3, v4;

    // Define 2 states, drive control or automatic control
    enum Mode {
        DRIVER_CONTROL,
        AUTOMATIC_CONTROL
    }

    Mode currentMode = Mode.DRIVER_CONTROL;


    // The angle we want to align to when we press Y
    double targetAngle = Math.toRadians(45);


    @Override
    public void runOpMode() throws InterruptedException {

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);
        drive.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        telemetry.clearAll();
        telemetry.update();

        /*
         * in autonom trebuie pus asta: TODO: LocalizareThobor.currentPose = drive.getPoseEstimate();
         * cu linia de mai sus pusa, putem sa ne pastram locatia din autonom in TeleOP pentru
         * a putea urmari robotul in continuare
         */
        drive.setPoseEstimate(LocalizareThobor.currentPose);

        AsteaptaStart();

        if (isStopRequested()) return;

        while (opModeIsActive() && !isStopRequested()) {
            drive.update();

            switch (currentMode) {
                case DRIVER_CONTROL:
                    drive.setWeightedDrivePower(
                            new Pose2d(
                                    -gamepad1.left_stick_y,
                                    -gamepad1.left_stick_x,
                                    -gamepad1.right_stick_x
                            )
                    );
                    while (gamepad1.dpad_down) {
                        v1 = (-putere_dpad);
                        v2 = (-putere_dpad);
                        v3 = (-putere_dpad);
                        v4 = (-putere_dpad);
//                      drive.setMotorPowers(v1 * full_power, v3 * full_power, v4 * full_power, v2 * full_power);
                        drive.setMotorPowersFull(v1, v3, v4, v2);
                    }
                    while (gamepad1.dpad_right) {
                        v1 = (+putere_dpad);
                        v2 = (-putere_dpad);
                        v3 = (-putere_dpad);
                        v4 = (putere_dpad);
                        drive.setMotorPowersFull(v1, v3, v4, v2);
                    }
                    while (gamepad1.dpad_up) {
                        v1 = (putere_dpad);
                        v2 = (putere_dpad);
                        v3 = (putere_dpad);
                        v4 = (putere_dpad);
                        drive.setMotorPowersFull(v1, v3, v4, v2);
                    }
                    while (gamepad1.dpad_left) {
                        v1 = (-putere_dpad);
                        v2 = (putere_dpad);
                        v3 = (putere_dpad);
                        v4 = (-putere_dpad);
                        drive.setMotorPowersFull(v1, v3, v4, v2);
                    }

                    while (gamepad1.left_trigger != 0) {
                        drive.setMotorPowers(-putere_rotire, -putere_rotire, putere_rotire, putere_rotire);
                    }

                    while (gamepad1.right_trigger != 0) {
                        drive.setMotorPowers(putere_rotire, putere_rotire, -putere_rotire, -putere_rotire);
                    }
                    drive.update();
                    Pose2d poseEstimate = drive.getPoseEstimate();
                    telemetry.addData("x", poseEstimate.getX());
                    telemetry.addData("y", poseEstimate.getY());
                    telemetry.addData("heading", poseEstimate.getHeading());
                    telemetry.addData("ce_Se_happen", currentMode);


                    if (gamepad1.left_bumper) {
                        drive.Absoarbe(putereAbsorbtie);
                    } else {
                        drive.Absoarbe(0);
                    }
                    if (gamepad1.right_bumper) {
                        drive.Arunca(putereAruncare);
                    } else {
                        drive.Arunca(0);
                    }

                    if (gamepad2.dpad_up) {
                        drive.RidicaWooble(-putereWooble);

                    } else if (gamepad2.dpad_down) {
                        drive.RidicaWooble(putereWooble);

                    } else {
                        drive.RidicaWooble(0);

                    }
                    //----------[tragaci]---------------------------------------------------------------------
                    if (gamepad2.dpad_right && buttonReleased5 == 1) {
                        buttonReleased5 = 0;
                        if (ghearaPusa == 0) {
                            ghearaPusa = 1;
                            drive.WoobleGheara(pozitie_gheara_closed);
                            telemetry.addLine("Gheara s-a strans");
                        } else {
                            ghearaPusa = 0;
                            drive.WoobleGheara(pozitie_gheara_open);
                            telemetry.addLine("Gheara s-a deschis");
                        }
                    }
                    if (!gamepad2.dpad_right) buttonReleased5 = 1;


                    //----------[tragaci]---------------------------------------------------------------------
                    if (gamepad2.right_bumper && buttonReleased == 1) {
                        buttonReleased = 0;
                        if (tragaciPus == 0) {
                            tragaciPus = 1;
                            drive.TragaciPozitie(tragaciInchis);
                            telemetry.addLine("Tragaci s-a strans");
                        } else {
                            tragaciPus = 0;
                            drive.TragaciPozitie(tragaciDeschis);
                            telemetry.addLine("Tragaci s-a deschis");
                        }
                    }
                    if (!gamepad2.right_bumper) buttonReleased = 1;
                    //----------[organizator]---------------------------------------------------------------------
                    if (gamepad2.left_bumper && buttonReleased2 == 1) {
                        buttonReleased2 = 0;
                        if (organizatorPus == 0) {
                            organizatorPus = 1;
                            drive.OrganizatorPozitie(organizatorInchis);
                            telemetry.addLine("Organizator s-a strans");

                        } else {
                            organizatorPus = 0;
                            drive.OrganizatorPozitie(organizatorDeschis);
                            telemetry.addLine("Organizator s-a deschis");
                        }
                    }
                    if (!gamepad2.left_bumper) buttonReleased2 = 1;


                    //----------[fatete]---------------------------------------------------------------------
                    if (gamepad1.a && buttonReleased3 == 1) {
                        buttonReleased3 = 0;
                        if (fatetePuse == 0) {
                            fatetePuse = 1;
                            drive.fatete(putere_fata_dr, putere_fata_st);
                            telemetry.addLine("Fatete s-au deschis");
                        } else {
                            fatetePuse = 0;
                            drive.fatete(0, 0);
                            telemetry.addLine("Fatete s-au inchis");
                        }
                    }
                    if (!gamepad1.a) buttonReleased3 = 1;
/*
                    if (gamepad2.right_bumper) {
                        if (right) {
                            drive.DuWooble(3); // il duce
                            right = false;
                        } else {
                            drive.DuWooble(4); // il intoarce
                            right = true;
                        }
                    }
                    if (gamepad2.left_bumper) {
                        if(right) {
                            drive.DuWooble(6);
//                            right = !right;
                        }
                        else{
                            drive.DuWooble(4);
                            right = !right;
                        }
                    }
*/

                    if (gamepad2.a)
                    {
                        drive.AruncaAutomat(3);
                    }

                    /*if (gamepad2.a) {
                        *//*
                         * apasam pe a din gamepad2 si mergem la pozitia de aruncare
                         * *//*

                        Trajectory traj1 = drive.trajectoryBuilder(poseEstimate)
                                .lineToLinearHeading(posAruncare)
                                .build();

                        drive.followTrajectoryAsync(traj1);

                        currentMode = Mode.AUTOMATIC_CONTROL;
                    } else if (gamepad2.b) {
                        *//*
                         * apasam pe b din gamepad2 si mergem la pozitia de parcare
                         * *//*

                        Trajectory traj1 = drive.trajectoryBuilder(poseEstimate)
                                .lineToLinearHeading(posParcare)
                                .build();

                        drive.followTrajectoryAsync(traj1);

                        currentMode = Mode.AUTOMATIC_CONTROL;
                    } else if (gamepad2.y) {
                        *//*
                         * apasam pe y din gamepad2 si ne rotim la 45 grade fata de pozitia initiala
                         * *//*

                        drive.turnAsync(Angle.normDelta(targetAngle - poseEstimate.getHeading()));

                        currentMode = Mode.AUTOMATIC_CONTROL;
                    }*/
                    break;
                case AUTOMATIC_CONTROL:
                    // daca apasam pe x din gmp2 se opreste autonomul
                    if (gamepad2.x) {
                        drive.cancelFollowing();
                        currentMode = Mode.DRIVER_CONTROL;
                    }

                    //ne intoarcem inapoi in driving mode dupa ce e gata autonom
                    if (!drive.isBusy()) {
                        currentMode = Mode.DRIVER_CONTROL;
                    }
                    break;
            }
        }
    }

    public void AsteaptaStart() // pentru eroarea cu Motorola
    {
        while (!opModeIsActive() && !isStopRequested()) {
            telemetry.update();
        }
    }
}