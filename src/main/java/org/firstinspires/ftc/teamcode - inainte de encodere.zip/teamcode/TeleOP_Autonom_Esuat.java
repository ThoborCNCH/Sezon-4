/*
 *
 * ©Thobor 2020-2021
 *
 *           _
 *       .__(.)< (MEOW)
 *        \___)
 * ~~~~~~~~~~~~~~~~~~
 *
 *
 */


package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.util.Angle;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.drive.ThoborVARS;

import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.full_power;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.intors180;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorDeschis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorInchis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.posAruncare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.posParcare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAbsorbtie;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAruncare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_dpad;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_rotire;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.startVector;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.startpos;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciDeschis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciInchis;

@TeleOp(name = "TeleOP din Autonom", group = "TeleOP")
@Disabled
public class TeleOP_Autonom_Esuat extends LinearOpMode {

    public double tragaciPus = 0;
    public double organizatorPus = 0;
    double buttonReleased = 1;
    double buttonReleased2 = 1;
    double v1, v2, v3, v4;
    enum ce_Se_happen {
        DRIVER_CONTROL,
        AUTOMATIC_CONTROL
    }
    ce_Se_happen currentMode = ce_Se_happen.DRIVER_CONTROL;

    int debug = -1;


    @Override
    public void runOpMode() {

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);
        drive.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        telemetry.clearAll();
        telemetry.update();

        /*
        * in autonom trebuie pus asta: TODO: LocalizareThobor.currentPose = drive.getPoseEstimate();
        * cu linia de mai sus pusa, putem sa ne pastram locatia din autonom in TeleOP pentru
        * a putea urmari robotul in continuare
         */
        drive.setPoseEstimate(LocalizareThobor.currentPose);
        ce_Se_happen currentMode = ce_Se_happen.DRIVER_CONTROL;

        AsteaptaStart();
        drive.TragaciPozitie(tragaciInchis);
        while (opModeIsActive())
        {
            switch (currentMode) {
                case DRIVER_CONTROL:
                    //=======[miscarea din localization]=====
                    drive.setWeightedDrivePower(
                            new Pose2d(
                                    -gamepad1.left_stick_y,
                                    -gamepad1.left_stick_x,
                                    -gamepad1.right_stick_x
                            )
                    );
                    while (gamepad1.dpad_down) {
                        v1 = (-putere_dpad);
                        v2 = (-putere_dpad);
                        v3 = (-putere_dpad);
                        v4 = (-putere_dpad);
                        drive.setMotorPowers(v1 * full_power, v3 * full_power, v4 * full_power, v2 * full_power);
                    }
                    while (gamepad1.dpad_right) {
                        v1 = (+putere_dpad);
                        v2 = (-putere_dpad);
                        v3 = (-putere_dpad);
                        v4 = (putere_dpad);
                        drive.setMotorPowers(v1 * full_power, v3 * full_power, v4 * full_power, v2 * full_power);
                    }
                    while (gamepad1.dpad_up) {
                        v1 = (putere_dpad);
                        v2 = (putere_dpad);
                        v3 = (putere_dpad);
                        v4 = (putere_dpad);
                        drive.setMotorPowers(v1 * full_power, v3 * full_power, v4 * full_power, v2 * full_power);
                    }
                    while (gamepad1.dpad_left) {
                        v1 = (-putere_dpad);
                        v2 = (putere_dpad);
                        v3 = (putere_dpad);
                        v4 = (-putere_dpad);
                        drive.setMotorPowers(v1 * full_power, v3 * full_power, v4 * full_power, v2 * full_power);
                    }

                    while(gamepad1.left_trigger != 0)
                    {
                        drive.setMotorPowers(-putere_rotire, -putere_rotire, putere_rotire, putere_rotire);
                    }

                    while(gamepad1.right_trigger != 0)
                    {
                        drive.setMotorPowers(putere_rotire, putere_rotire,-putere_rotire,-putere_rotire);
                    }
                    drive.update();
                    Pose2d poseEstimate = drive.getPoseEstimate();
                    telemetry.addData("x", poseEstimate.getX());
                    telemetry.addData("y", poseEstimate.getY());
                    telemetry.addData("heading", poseEstimate.getHeading());
                    telemetry.addData("ce_Se_happen", currentMode);


                    if (gamepad1.left_bumper) {
                        drive.Absoarbe(putereAbsorbtie);
                    } else {
                        drive.Absoarbe(0);
                    }
                    if (gamepad1.right_bumper) {
                        drive.Arunca(putereAruncare);
                    } else {
                        drive.Arunca(0);
                    }
                    //----------[tragaci]---------------------------------------------------------------------
                    if (gamepad1.x && buttonReleased == 1) {
                        buttonReleased = 0;
                        if (tragaciPus == 0) {
                            tragaciPus = 1;
                            drive.TragaciPozitie(tragaciInchis);
                            telemetry.addLine("Tragaci s-a strans");
                        } else {
                            tragaciPus = 0;
                            drive.TragaciPozitie(tragaciDeschis);
                            telemetry.addLine("Tragaci s-a deschis");
                        }
                    }
                    if (!gamepad1.x) buttonReleased = 1;
                    //----------[organizator]---------------------------------------------------------------------
                    if (gamepad1.y && buttonReleased2 == 1)
                    {
                        buttonReleased2 = 0;
                        if (organizatorPus == 0) {
                            organizatorPus = 1;
                            drive.OrganizatorPozitie(organizatorInchis);
                            telemetry.addLine("Organizator s-a strans");

                        } else {
                            organizatorPus = 0;
                            drive.OrganizatorPozitie(organizatorDeschis);
                            telemetry.addLine("Organizator s-a deschis");
                        }
                    }
                    if (!gamepad1.y) buttonReleased2 = 1;

                    if (gamepad2.a)
                    {
                        /*Daca apasam gamepad2.a mergem la pozitia de aruncare, momentan test
                        * va fi automat trecut in modul autonom
                        * */
                        debug = 1;

                        Trajectory traj1 = drive.trajectoryBuilder(poseEstimate)
                                .lineToLinearHeading(posAruncare)
                                .build();

                        drive.followTrajectoryAsync(traj1);

                        telemetry.addLine("Ai apasat pe a si amu mere la aruncare");

                        currentMode = ce_Se_happen.AUTOMATIC_CONTROL;
                    }
                    if (gamepad2.b)
                    {
                        /*Daca apasam gamepad2.b mergem la pozitia de parcare, momentan test
                         * va fi automat trecut in modul autonom
                         * */
                        debug = 2;
                        Trajectory traj1 = drive.trajectoryBuilder(poseEstimate)
                                .lineToLinearHeading(posParcare)
                                .build();

                        drive.followTrajectoryAsync(traj1);

                        telemetry.addLine("Ai apasat pe b si amu mere la parcare");

                        currentMode = ce_Se_happen.AUTOMATIC_CONTROL;
                    }
                    if (gamepad2.y)
                    {
                        debug = 3;
                        Trajectory traj1 = drive.trajectoryBuilder(poseEstimate)
                                .splineTo(startVector, intors180)
                                .build();
                        drive.followTrajectoryAsync(traj1);

                        telemetry.addLine("Ai apasat pe y si amu mere la perete");

                        currentMode = ce_Se_happen.AUTOMATIC_CONTROL;

                    }
                    telemetry.update();
                    break;


                case AUTOMATIC_CONTROL:
                    Pose2d pose2Estimate = drive.getPoseEstimate();
                    //aici anulam
                    if(debug == 1)
                        telemetry.addLine("acum tre sa ma duc la aruncare");
                    else if(debug == 2) {
                        telemetry.addLine("acum tre sa ma duc la parcare");
                        Trajectory traj1 = drive.trajectoryBuilder(pose2Estimate)
                                .lineToLinearHeading(posParcare)
                                .build();

                        drive.followTrajectoryAsync(traj1);
                    }else if (debug == 3)
                        telemetry.addLine("acum tre sa ma duc la perete");
                    else
                        telemetry.addLine("nu stiu ce se happen in viata, eeeee");

                    if (gamepad2.x) {
                        drive.cancelFollowing();
                        currentMode = ce_Se_happen.DRIVER_CONTROL;
                    }

                    if (!drive.isBusy()) {
                        currentMode = ce_Se_happen.DRIVER_CONTROL;
                    }
                    telemetry.update();
                    break;
            }
            telemetry.update();
        }
    }
    public void AsteaptaStart() // pentru eroarea cu Motorola
    {
        while (!opModeIsActive() && !isStopRequested())
        {
            telemetry.update();
        }
    }
}
  