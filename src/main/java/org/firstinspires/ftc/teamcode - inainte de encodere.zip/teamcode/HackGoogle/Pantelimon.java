package org.firstinspires.ftc.teamcode.HackGoogle;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.firstinspires.ftc.robotcore.external.tfod.TFObjectDetector;
import org.firstinspires.ftc.teamcode.LocalizareThobor;
import org.firstinspires.ftc.teamcode.R;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.drive.ThoborVARS;

import java.util.List;
import java.util.Random;

import static java.lang.Thread.sleep;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.*;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.pozitie_gheara_closed;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.pozitie_gheara_open;
@Disabled
@Autonomous(name = ".Pantelimon", group = "Amin")
public class Pantelimon extends LinearOpMode {

    private static final String KEY =
            "ARhzqPT/////AAABmcks6V9uRE/4vJE+8qBUvnsYPXUfYlpJ8y+pzVN/GpzCrJsVanetvGKZxaJMs+3LmpTosqzKWHhdAiOzqd3kFmr4WYOWRErWkQuuVRx5/merGbBTYOAKQ9rkri+O3XR/l3bWk3zVlXUH7wXisifJcM2xoXGON4lYuETqenXu4NFfqOXkDGWI1nBNMM1dFW6AhLEuGt0R1TP6ToWiA1rk6dBvg7W3jGDi7eGYdvQhuo5I+6/ffn/OAyWnt+5DiJFVK365Cubaa0IE5xO3J4SSNcVXaho39lO5o7EhtCmqO2icWi8bYv7o+DHXWPsKfPByyrKSjEaXpvBNQ6S7P5pw9p5I5t6XafbS2LxYE5AJ6zH6";

    private static final String TFOD_MODEL_ASSET = "UltimateGoal.tflite";
    private static final String LABEL_FIRST_ELEMENT = "Quad";
    private static final String LABEL_SECOND_ELEMENT = "Single";

    private VuforiaLocalizer vuforia;
    private TFObjectDetector tfod;

    int path = -1;

    public ElapsedTime timpD = new ElapsedTime();

    @Override
    public void runOpMode() throws InterruptedException {
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        initCam();

        if (tfod != null) {
            tfod.activate();
            tfod.setZoom(2.5, 16.0 / 9.0);
        }

        SampleMecanumDrive robot = new SampleMecanumDrive(hardwareMap);

        robot.setPoseEstimate(startpos);
        
        AsteaptaStart();


        if (opModeIsActive()) {
            while (opModeIsActive()) {
                Trajectory traj = robot.trajectoryBuilder(startpos)
                        .lineToLinearHeading(LA_INELE)
                        .build();

                robot.followTrajectory(traj);
                Detectie();
                tfod.shutdown();

                telemetry.addData("poz: ", path);
                telemetry.update();

                if (path == 1) {
                    Trajectory laA = robot.trajectoryBuilder(traj.end())
                            .lineToLinearHeading(LA_A)
                            .build();
                    robot.followTrajectory(laA);

                    robot.DuWooble(1);

                    Trajectory inapoi_la_wabble1 = robot.trajectoryBuilder(laA.end())
                            .splineToLinearHeading(INAPOI_LA_WABBLE_A, Math.toRadians(0))
                            .build();
                    robot.followTrajectory(inapoi_la_wabble1);

                    robot.DuWooble(2);

                    Trajectory deliver_kebab = robot.trajectoryBuilder(inapoi_la_wabble1.end())
                            .splineToLinearHeading(LA_A, Math.toRadians(0))
                            .build();
                    robot.followTrajectory(deliver_kebab);

                    robot.DuWooble(1);

                    Trajectory du_te_sa_scuipi_a = robot.trajectoryBuilder(deliver_kebab.end())
                            .lineToLinearHeading(ARUNCARE)
                            .build();
                    robot.followTrajectory(du_te_sa_scuipi_a);

                    robot.AruncaAutomat(3);

                    Trajectory park = robot.trajectoryBuilder(du_te_sa_scuipi_a.end())
                            .lineToLinearHeading(PARK)
                            .build();
                    robot.followTrajectory(park);
                }
                if (path == 2) {
                    Trajectory reven = robot.trajectoryBuilder(traj.end())
                            .splineToLinearHeading(REVEN, Math.toRadians(0.0)).
                                    build();
                    robot.followTrajectory(reven);

                    Trajectory laB = robot.trajectoryBuilder(reven.end())
                            .splineToLinearHeading(LA_B, Math.toRadians(120))
                            .build();
                    robot.followTrajectory(laB);

                    robot.DuWooble(1);

                    Trajectory inapoi_la_wabble2 = robot.trajectoryBuilder(laB.end(), true)
                            .splineToSplineHeading(INAPOI_LA_WABBLE_B, Math.toRadians(-100))
                            .build();
                    robot.followTrajectory(inapoi_la_wabble2);

//                    robot.DuWooble(2);
                    robot.DuWooble(3);
                    sleep(170);
                    robot.WoobleGheara(pozitie_gheara_closed);
                    robot.RidicaWooble(0.4);
                    sleep(300);
//                    robot.wooblemoto.setMotorDisable();
                    robot.wooblemoto.setPower(0);

                    Trajectory deliver_pizza = robot.trajectoryBuilder(inapoi_la_wabble2.end())
                            .splineToSplineHeading(LA_B, Math.toRadians(-60))
                            .build();
                    robot.followTrajectory(deliver_pizza);

                    robot.DuWooble(7);


                    Trajectory du_te_sa_scuipi_b = robot.trajectoryBuilder(deliver_pizza.end())
                            .lineToLinearHeading(ARUNCARE_B)
                            .build();
                    robot.followTrajectory(du_te_sa_scuipi_b);

                    robot.AruncaAutomat(3);

                    Trajectory park = robot.trajectoryBuilder(du_te_sa_scuipi_b.end())
                            .lineToLinearHeading(PARK)
                            .build();
                    robot.followTrajectory(park);

                }
                if (path == 3) {
                    Trajectory reven = robot.trajectoryBuilder(traj.end())
                            .lineToSplineHeading(REVEN).
                                    build();
                    robot.followTrajectory(reven);
                    sleep(70);

                    Trajectory laC = robot.trajectoryBuilder(reven.end())
                            .lineToSplineHeading(LA_C)
                            .build();
                    robot.followTrajectory(laC);

                    robot.DuWooble(1);

                    sleep(200);

                    Trajectory inapoi_la_wabble3 = robot.trajectoryBuilder(laC.end())
                            .splineToSplineHeading(INAPOI_LA_WABBLE_C, Math.toRadians(-100))
                            .build();
                    robot.followTrajectory(inapoi_la_wabble3);

                    robot.DuWooble(3);
                    robot.WoobleGheara(pozitie_gheara_closed);
                    robot.RidicaWooble(0.4);
                    sleep(300);
                    robot.wooblemoto.setPower(0);

                    sleep(200);

                    Trajectory deliver_shaorma = robot.trajectoryBuilder(inapoi_la_wabble3.end())
                            .splineToSplineHeading(LA_C, Math.toRadians(-60))
                            .build();
                    robot.followTrajectory(deliver_shaorma);

//                    robot.DuWooble(1);
                    sleep(200);

//                    robot.wooblemoto.setMotorEnable();
//                    robot.WoobleGheara(pozitie_gheara_open);
                    robot.DuWooble(7);
                    sleep(200);

                    Trajectory du_te_sa_scuipi_a = robot.trajectoryBuilder(deliver_shaorma.end())
                            .lineToLinearHeading(ARUNCARE_B)
                            .build();
                    robot.followTrajectory(du_te_sa_scuipi_a);
                    robot.AruncaAutomat(3);


                    Trajectory park = robot.trajectoryBuilder(du_te_sa_scuipi_a.end())
                            .lineToLinearHeading(PARK)
                            .build();
                    robot.followTrajectory(park);

                }

                LocalizareThobor.currentPose = robot.getPoseEstimate();
                stop();
            }
        }
    }

    private void initCam() {
        msStuckDetectStop = 2500;

        //init vuforia
        VuforiaLocalizer.Parameters vuforiaParams = new VuforiaLocalizer.Parameters(R.id.cameraMonitorViewId);
        vuforiaParams.vuforiaLicenseKey = ThoborVARS.Vuforia_Key;
        vuforiaParams.cameraName = hardwareMap.get(WebcamName.class, "Webcam 1");
        vuforiaParams.cameraDirection = VuforiaLocalizer.CameraDirection.BACK;

        VuforiaLocalizer vuforia = ClassFactory.getInstance().createVuforia(vuforiaParams);

        //pentru a vedea pe dash camera
        FtcDashboard.getInstance().startCameraStream(vuforia, 0);

        //init tenserflow
        int tfodMonitorViewId = hardwareMap.appContext.getResources().getIdentifier(
                "tfodMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        TFObjectDetector.Parameters tfodParameters = new TFObjectDetector.Parameters(tfodMonitorViewId);
        tfodParameters.minResultConfidence = 0.8f;
        tfod = ClassFactory.getInstance().createTFObjectDetector(tfodParameters, vuforia);
        tfod.loadModelFromAsset(TFOD_MODEL_ASSET, LABEL_FIRST_ELEMENT, LABEL_SECOND_ELEMENT);

    }

    private void AsteaptaStart() {
        while (!opModeIsActive() && !isStopRequested()) {
            telemetry.update();
        }
    }

    private void Detectie() {
        timpD.reset();
        while (timpD.time() < 2.5) {
            if (tfod != null) {
                List<Recognition> updatedRecognitions = tfod.getUpdatedRecognitions();
                if (updatedRecognitions != null) {
                    telemetry.addData("# Object Detected", updatedRecognitions.size());
                    if (updatedRecognitions.size() == 0) {
                        telemetry.addData("Target Zone", "A");
                        path = 1;
                    } else {
                        for (Recognition recognition : updatedRecognitions) {
                            if (recognition.getLabel().equals("Quad")) {
                                telemetry.addData("Target Zone", "C");
                                path = 3;
                            } else if (recognition.getLabel().equals("Single")) {
                                telemetry.addData("Target Zone", "B");
                                path = 2;
                            } else {
                                telemetry.addData("Target Zone", "UNKNOWN");
                                Random rand = new Random();
                                path = rand.nextInt(3) + 1;
                            }
                        }
                    }
                    telemetry.update();
                }
            }

        }
    }
}
