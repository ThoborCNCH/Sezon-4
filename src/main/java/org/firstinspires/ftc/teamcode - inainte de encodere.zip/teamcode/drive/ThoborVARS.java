/*
 *
 * ©Thobor 2020-2021
 *
 *           _
 *       .__(.)< (MEOW)
 *        \___)
 * ~~~~~~~~~~~~~~~~~~
 *
 *
 */

package org.firstinspires.ftc.teamcode.drive;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;

/*
 * Servus, daca vrei sa modifici ceva pe aici prin dashboard ca sa nu dai push de 100 de ori
 * esti invitatul meu sa o faci
 * semnat, Hanga, hai te pwp
 */
@Config
public class ThoborVARS {

    /*
     *
     *          _.-/`)                              .-.
     *         // / / )                           __| |__
     *      .=// / / / )                         [__   __]
     *     //`/ / / / /      __________             | |
     *    // /     ` /      /          \            | |
     *   ||         /       | WE PRAY  |            | |
     *    \\       /        | TO WORK  |            '-'
     *     ))    .'         \_________/
     *    //    /
     *         /
     *
     */

    //astea s de informatii
    /**
     *  aici sunt in cm
     public static double Jumatate_Patrat = 30.48; //jumatate de patrat de teren
     public static double Un_Patrat_Intreg = 60.96; // un patrat de teren
     public static double GradeRotire = 45;   // grade
     public static double Patrate_De_teren_4 = 243.84;  // 4 patrate de teren
     public static double Patrate_de_teren_2 = 121.92;  // 2 patrate de teren
     public static double Patrate_de_teren_3 = 182.88;  // 3 patrate de teren
     *
     /** aici folosim distanta in inchi, o placa are 2' adica 24", de aici ies calculele:
     public static double Jumatate_Patrat = 12; //jumatate de patrat de teren
     public static double Un_Patrat_Intreg = 24; // un patrat de teren
     public static double GradeRotire = 45;   // grade
     public static double Patrate_De_teren_4 = 96;  // 4 patrate de teren
     public static double Patrate_de_teren_2 = 48;  // 2 patrate de teren
     public static double Patrate_de_teren_3 = 72;  // 3 patrate de teren
     * *********************************************************************************/
    public static double Jumatate_Patrat = 12; //jumatate de patrat de teren
    public static double Un_Patrat_Intreg = 24; // un patrat de teren
    public static double GradeRotire = 45;   // grade
    public static double Patrate_De_teren_4 = 96;  // 4 patrate de teren
    public static double Patrate_de_teren_2 = 48;  // 2 patrate de teren
    public static double Patrate_de_teren_3 = 72;  // 3 patrate de teren


    public static double DirLR = 0;
    public static double DirRR = 1;
    public static double DirRF = 1;
    public static double DirLF = 0;

    public static double DirWooble = 1;

    public static double tragaciDeschis = 0.9;
    public static double tragaciInchis = 0.5;
    public static double putereAbsorbtie = -0.9;
    public static double putereAruncare = 0.75;

    public static double putere_fata_dr = -1;
    public static double putere_fata_st = 1;

    public static double pozitie_gheara_closed = 0.7;
    public static double  pozitie_gheara_open = 0.3;

    public static double putereWooble = 1;

    public static double organizatorInchis = -0.3;
    public static double organizatorDeschis = 0.37;

    public static double putere_dpad = 0.6;
    public static double putere_rotire = 0.17;
    public static double full_power = 1;

    public static double GradeInceput = 35;

    public static final String Vuforia_Key =
            "ARhzqPT/////AAABmcks6V9uRE/4vJE+8qBUvnsYPXUfYlpJ8y+pzVN/GpzCrJsVanetvGKZxaJMs+3LmpTosqzKWHhdAiOzqd3kFmr4WYOWRErWkQuuVRx5/merGbBTYOAKQ9rkri+O3XR/l3bWk3zVlXUH7wXisifJcM2xoXGON4lYuETqenXu4NFfqOXkDGWI1nBNMM1dFW6AhLEuGt0R1TP6ToWiA1rk6dBvg7W3jGDi7eGYdvQhuo5I+6/ffn/OAyWnt+5DiJFVK365Cubaa0IE5xO3J4SSNcVXaho39lO5o7EhtCmqO2icWi8bYv7o+DHXWPsKfPByyrKSjEaXpvBNQ6S7P5pw9p5I5t6XafbS2LxYE5AJ6zH6";

    public static Pose2d startpos = new Pose2d(-60, -50, 0);
    public static Vector2d startVector = new Vector2d(-60, -50);

    public static Pose2d fugiApos = new Pose2d(3, -57, Math.toRadians(0));

    public static Pose2d wooble2pos = new Pose2d(-40, -25, 0);
    public static Vector2d wooble2Vector = new Vector2d(-40, -25);

    public static Vector2d fugiB = new Vector2d(30,-37);

    public static double intors180 = Math.toRadians(180);
    public static Pose2d posAruncare = new Pose2d(-10, -30, 0);
    public static Pose2d posParcare = new Pose2d(10, -30, 0);

}
