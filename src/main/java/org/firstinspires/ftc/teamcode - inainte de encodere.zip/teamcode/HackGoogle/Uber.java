package org.firstinspires.ftc.teamcode.HackGoogle;

import com.acmerobotics.roadrunner.trajectory.Trajectory;

import org.firstinspires.ftc.teamcode.LocalizareThobor;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.drive.opmode.DriveVelocityPIDTuner;

import static java.lang.Thread.sleep;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.INAPOI_LA_WABBLE_A;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.INAPOI_LA_WABBLE_B;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.INAPOI_LA_WABBLE_C;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.LA_A;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.LA_B;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.LA_C;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.PARK_A;
import static org.firstinspires.ftc.teamcode.HackGoogle.NuUmbla.REVEN;

public class Uber {
    public static void DU_TE_LA_A(SampleMecanumDrive robot, Trajectory traj) throws InterruptedException {
        Trajectory laA = robot.trajectoryBuilder(traj.end())
                .lineToLinearHeading(LA_A)
                .addDisplacementMarker(() -> {
                    try {
                        robot.AruncaAutomat(3);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                })
                .build();
        robot.followTrajectory(laA);

        sleep(200);

        Trajectory inapoi_la_wabble1 = robot.trajectoryBuilder(laA.end())
                .splineToLinearHeading(INAPOI_LA_WABBLE_A, Math.toRadians(0))
                .build();
        robot.followTrajectory(inapoi_la_wabble1);

        sleep(200);

        Trajectory laA2 = robot.trajectoryBuilder(inapoi_la_wabble1.end())
                .splineToLinearHeading(LA_A, Math.toRadians(0))
                .build();
        robot.followTrajectory(laA2);
        sleep(100);

        Trajectory park = robot.trajectoryBuilder(laA2.end())
                .lineTo(PARK_A)
                .build();
        robot.followTrajectory(park);
    }

    public static void DU_TE_LA_B(SampleMecanumDrive robot, Trajectory traj) {
        Trajectory reven = robot.trajectoryBuilder(traj.end())
                .splineToLinearHeading(REVEN, Math.toRadians(0.0)).
                        build();
        robot.followTrajectory(reven);

        Trajectory laB = robot.trajectoryBuilder(reven.end())
                .splineToLinearHeading(LA_B, Math.toRadians(120))
                .addDisplacementMarker(() -> {
                    try {
                        robot.AruncaAutomat(3);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                })
                .build();
        robot.followTrajectory(laB);

        Trajectory inapoi_la_wabble2 = robot.trajectoryBuilder(laB.end(), true)
                .splineToLinearHeading(INAPOI_LA_WABBLE_B, Math.toRadians(-80))
                .build();
        robot.followTrajectory(inapoi_la_wabble2);


        Trajectory deliver_pizza = robot.trajectoryBuilder(inapoi_la_wabble2.end())
                .splineToLinearHeading(LA_B, Math.toRadians(-90))
                .build();
        robot.followTrajectory(deliver_pizza);
    }

    public static void DU_TE_LA_C(SampleMecanumDrive robot, Trajectory traj) {
        Trajectory laC = robot.trajectoryBuilder(traj.end())
                .lineToLinearHeading(LA_C)
                .addDisplacementMarker(() -> {
                    try {
                        robot.AruncaAutomat(3);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                })
                .build();
        robot.followTrajectory(laC);

        Trajectory inapoi_la_wabble3 = robot.trajectoryBuilder(laC.end(), true)
                .splineToLinearHeading(INAPOI_LA_WABBLE_C, Math.toRadians(-150))
                .build();
        robot.followTrajectory(inapoi_la_wabble3);

        Trajectory deliver_shaorma = robot.trajectoryBuilder(inapoi_la_wabble3.end(), true)
                .splineToLinearHeading(LA_C, Math.toRadians(-140))
                .build();
        robot.followTrajectory(deliver_shaorma);
    }

}
