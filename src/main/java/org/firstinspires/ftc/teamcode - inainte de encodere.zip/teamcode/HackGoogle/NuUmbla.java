package org.firstinspires.ftc.teamcode.HackGoogle;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;

@Config
public class NuUmbla {
    public static Pose2d startpos = new Pose2d(-64.00, -50.00, 0);
    public static Pose2d ARUNCARE = new Pose2d(0, -35, Math.toRadians(0));
    public static Pose2d ARUNCARE_B = new Pose2d(0, -35, Math.toRadians(0));
    public static Pose2d PARK = new Pose2d(15, -35);
    public static Pose2d LA_INELE = new Pose2d(-40, -50, Math.toRadians(45));
    public static Pose2d REVEN = new Pose2d(-15.00, -56.00, Math.toRadians(0.0));

    // PENTRU A
    public static Pose2d LA_A = new Pose2d(7, -53.00, Math.toRadians(0));
    public static Pose2d INAPOI_LA_WABBLE_A = new Pose2d(-32.00, -15.00, Math.toRadians(180));
    public static Vector2d PARK_A = new Vector2d(15.00, -30.00);

    //    PENTRU B
    public static Pose2d LA_B = new Pose2d(20.00, -30.00, Math.toRadians(180.0));
    public static Pose2d INAPOI_LA_WABBLE_B = new Pose2d(-27.90, -24.70, Math.toRadians(31.00));

    // PENTRU C
    public static Pose2d LA_C = new Pose2d(45.00, -53.00, Math.toRadians(180.0));
    public static Pose2d INAPOI_LA_WABBLE_C = new Pose2d(-27.45, -24, Math.toRadians(31.57));
//    public static Pose2d INAPOI_LA_WABBLE_C = new Pose2d(-21.52, -28.88, Math.toRadians(30.20));


    /*
               ######                ######
             ###     ####        ####     ###
            ##          ###    ###          ##
            ##             ####             ##
            ##             ####             ##
            ##           ##    ##           ##
            ##         ###      ###         ##
             ##  ########################  ##
          ######    ###            ###    ######
      ###     ##    ##              ##    ##     ###
   ###         ## ###      ####      ### ##         ###
  ##           ####      ########      ####           ##
 ##             ###     ##########     ###             ##
  ##           ####      ########      ####           ##
   ###         ## ###      ####      ### ##         ###
      ###     ##    ##              ##    ##     ###
          ######    ###            ###    ######
             ##  ########################  ##
            ##         ###      ###         ##
            ##           ##    ##           ##
            ##             ####             ##
            ##             ####             ##
            ##          ###    ###          ##
             ###     ####        ####     ###
               ######                ######
     
     */
}
