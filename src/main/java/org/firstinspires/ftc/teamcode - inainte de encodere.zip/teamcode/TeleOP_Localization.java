package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.full_power;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_dpad;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putere_rotire;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorInchis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.organizatorDeschis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAbsorbtie;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.putereAruncare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciInchis;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.tragaciDeschis;

@TeleOp(name = "TeleOP Thobor", group = "TeleOP")
@Disabled
public class TeleOP_Localization extends LinearOpMode {

    public double tragaciPus = 0;
    public double organizatorPus = 0;
    double buttonReleased = 1;
    double buttonReleased2 = 1;
    double v1, v2, v3, v4;
    @Override
    public void runOpMode() {

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);
        drive.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        telemetry.clearAll();
        telemetry.update();

        /*
        * in autonom trebuie pus asta: TODO: LocalizareThobor.currentPose = drive.getPoseEstimate();
        * cu linia de mai sus pusa, putem sa ne pastram locatia din autonom in TeleOP pentru
        * a putea urmari robotul in continuare
         */
        drive.setPoseEstimate(LocalizareThobor.currentPose);

        AsteaptaStart();
        drive.TragaciPozitie(tragaciInchis);
        while (opModeIsActive())
        {
            //=======[miscarea din localization]=====
            drive.setWeightedDrivePower(
                    new Pose2d(
                            -gamepad1.left_stick_y,
                            -gamepad1.left_stick_x,
                            -gamepad1.right_stick_x
                    )
            );
            while(gamepad1.dpad_down)
            {
                v1 = (-putere_dpad);
                v2 = (-putere_dpad);
                v3 = (-putere_dpad);
                v4 = (-putere_dpad);
                drive.setMotorPowers(v1*full_power, v3 * full_power,v4*full_power,v2*full_power);
            }
            while(gamepad1.dpad_right)
            {
                v1 = (+putere_dpad);
                v2 = (-putere_dpad);
                v3 = (-putere_dpad);
                v4 = (putere_dpad);
                drive.setMotorPowers(v1*full_power, v3 * full_power,v4*full_power,v2*full_power);
            }
            while(gamepad1.dpad_up)
            {
                v1 = (putere_dpad);
                v2 = (putere_dpad);
                v3 = (putere_dpad);
                v4 = (putere_dpad);
                drive.setMotorPowers(v1*full_power, v3 * full_power,v4*full_power,v2*full_power);
            }
            while(gamepad1.dpad_left)
            {
                v1 = (-putere_dpad);
                v2 = (putere_dpad);
                v3 = (putere_dpad);
                v4 = (-putere_dpad);
                drive.setMotorPowers(v1*full_power, v3 * full_power,v4*full_power,v2*full_power);
            }

            while(gamepad1.left_trigger != 0)
            {
                drive.setMotorPowers(-putere_rotire, -putere_rotire, putere_rotire, putere_rotire);
            }

            while(gamepad1.right_trigger != 0)
            {
                drive.setMotorPowers(putere_rotire, putere_rotire,-putere_rotire,-putere_rotire);
            }
            drive.update();
            Pose2d poseEstimate = drive.getPoseEstimate();
            telemetry.addData("x", poseEstimate.getX());
            telemetry.addData("y", poseEstimate.getY());
            telemetry.addData("heading", poseEstimate.getHeading());

            if (gamepad1.left_bumper)
            {
                drive.Absoarbe(putereAbsorbtie);
            }
            else
            {
                drive.Absoarbe(0);
            }
            if (gamepad1.right_bumper)
            {
                drive.Arunca(putereAruncare);
            }
            else
            {
                drive.Arunca(0);
            }
            //----------[tragaci]---------------------------------------------------------------------
            if (gamepad1.x && buttonReleased == 1)
            {
                buttonReleased = 0;
                if (tragaciPus == 0)
                {
                    tragaciPus = 1;
                    drive.TragaciPozitie(tragaciInchis);
                    telemetry.addLine("Tragaci s-a strans");
                }
                else
                {
                    tragaciPus = 0;
                    drive.TragaciPozitie(tragaciDeschis);
                    telemetry.addLine("Tragaci s-a deschis");
                }
            }
            if (!gamepad1.x) buttonReleased = 1;
            //----------[organizator]---------------------------------------------------------------------
            if (gamepad1.y && buttonReleased2 == 1)
            {
                buttonReleased2 = 0;
                if (organizatorPus == 0)
                {
                    organizatorPus = 1;
                    drive.OrganizatorPozitie(organizatorInchis);
                    telemetry.addLine("Organizator s-a strans");

                }
                else
                {
                    organizatorPus = 0;
                    drive.OrganizatorPozitie(organizatorDeschis);
                    telemetry.addLine("Organizator s-a deschis");
                }
            }
            if (!gamepad1.y) buttonReleased2 = 1;
            telemetry.update();
        }
    }
    public void AsteaptaStart() // pentru eroarea cu Motorola
    {
        while (!opModeIsActive() && !isStopRequested())
        {
            telemetry.update();
        }
    }
}
  