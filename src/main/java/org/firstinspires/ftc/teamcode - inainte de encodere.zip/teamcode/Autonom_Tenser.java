/*
 *
 * ©Thobor 2020-2021
 *
 *           _
 *       .__(.)< (MEOW)
 *        \___)
 * ~~~~~~~~~~~~~~~~~~
 *
 *
 */


package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.firstinspires.ftc.robotcore.external.tfod.TFObjectDetector;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.drive.ThoborVARS;

import java.util.List;
import java.util.Random;

import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.fugiApos;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.fugiB;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.posParcare;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.startpos;
import static org.firstinspires.ftc.teamcode.drive.ThoborVARS.wooble2Vector;
@Disabled
@Autonomous(name = "Autonom_Tenser", group = "Autonom Oficial")
public class Autonom_Tenser extends LinearOpMode {
    private static final String TFOD_MODEL_ASSET = "UltimateGoal.tflite";
    private static final String LABEL_FIRST_ELEMENT = "Quad";
    private static final String LABEL_SECOND_ELEMENT = "Single";

    private TFObjectDetector tfod;

    int path = -1;

    public ElapsedTime timpD = new ElapsedTime();

    @Override
    public void runOpMode() {

        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());
        MereCamerele();

        if (tfod != null) {
            tfod.activate();
            tfod.setZoom(2.5, 16.0/9.0);
        }

        telemetry.addData(">", "Press Play to start op mode");
        telemetry.update();
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);

        drive.setPoseEstimate(startpos);

        AsteaptaStart();

        if (opModeIsActive())
        {
            while (opModeIsActive())
            {
                Trajectory traj = drive.trajectoryBuilder(startpos)
                        .lineToLinearHeading(new Pose2d(-35, -50, Math.toRadians(45)))
                        .build();

                drive.followTrajectory(traj);

                sleep(200);
                DetectieTest();
                if (path == 1)
                {
                    Trajectory trajA = drive.trajectoryBuilder(traj.end())
                            .lineToLinearHeading(fugiApos)
                            .build();

                    drive.followTrajectory(trajA);

                    Trajectory trajAWooble = drive.trajectoryBuilder(trajA.end(), true)
                            .splineTo(wooble2Vector, Math.toRadians(0))
                            .build();
                    drive.followTrajectory(trajAWooble);

                    Trajectory trajA2 = drive.trajectoryBuilder(trajAWooble.end(), true)
                            .lineToLinearHeading(fugiApos)
                            .build();

                    drive.followTrajectory(trajA2);

                    Trajectory trajABaza = drive.trajectoryBuilder(trajA2.end()) // momentan  ne intoarcem la start
                            .lineToLinearHeading(posParcare)
                            .build();
                    drive.followTrajectory(trajABaza);

                }
                if (path == 2) // b
                {
                    Trajectory trajB = drive.trajectoryBuilder(traj.end())
                            .splineTo(fugiB, Math.toRadians(0))
                            .build();
                    drive.followTrajectory(trajB);

                    Trajectory trajBWooble = drive.trajectoryBuilder(trajB.end(), true)
                            .splineTo(wooble2Vector, Math.toRadians(0))
                            .build();
                    drive.followTrajectory(trajBWooble);
                    Trajectory trajB2 = drive.trajectoryBuilder(trajBWooble.end(), true)
                            .splineTo(fugiB, Math.toRadians(0))
                            .build();
                    drive.followTrajectory(trajB2);
                    Trajectory trajBBaza = drive.trajectoryBuilder(trajB2.end()) // acum ne parcam
                            .lineToLinearHeading(posParcare)
                            .build();
                    drive.followTrajectory(trajBBaza);
                }
                if(path == 3)
                {
                    Trajectory trajC = drive.trajectoryBuilder(traj.end())
                            .splineTo(new Vector2d(55,-60), Math.toRadians(0))
                            .build();
                    drive.followTrajectory(trajC);
                    Trajectory trajBBaza = drive.trajectoryBuilder(trajC.end()) // momentan  ne intoarcem la start
                            .lineToLinearHeading(startpos)
                            .build();
                    drive.followTrajectory(trajBBaza);
                }
                LocalizareThobor.currentPose = drive.getPoseEstimate();
                stop();
            }
        }

        if (tfod != null)
        {
            tfod.shutdown();
        }
    }
    /*
     *               __
     *              / _)  (GRRRRR)
     *       .-^^^-/ /
     *   __/       /
     *  <__.|_|-|_|
     *
     */
    public void DetectieTest()
    {
        timpD.reset();
        while (timpD.time() < 2.5)
        {
            if (tfod != null) {
                List<Recognition> updatedRecognitions = tfod.getUpdatedRecognitions();
                if (updatedRecognitions != null) {
                    telemetry.addData("# Object Detected", updatedRecognitions.size());
                    if (updatedRecognitions.size() == 0) {
                        telemetry.addData("TFOD", "No items detected.");
                        telemetry.addData("Target Zone", "A");
                        path = 1;
                    } else {
                        for (Recognition recognition : updatedRecognitions) {
                            if (recognition.getLabel().equals("Single")) {
                                telemetry.addData("Target Zone", "B");
                                path = 2;
                            } else if (recognition.getLabel().equals("Quad")) {
                                telemetry.addData("Target Zone", "C");
                                path = 3;
                            } else {
                                telemetry.addData("Target Zone", "UNKNOWN");
                                Random rand = new Random();
                                path = rand.nextInt(3) + 1;
                            }
                        }
                    }
                    telemetry.update();
                }
            }
        }
    }

    public void MereCamerele()
    {
        msStuckDetectStop = 2500;
        VuforiaLocalizer.Parameters vuforiaParams = new VuforiaLocalizer.Parameters(R.id.cameraMonitorViewId);
        vuforiaParams.vuforiaLicenseKey = ThoborVARS.Vuforia_Key;
        vuforiaParams.cameraName = hardwareMap.get(WebcamName.class, "Webcam 1");
        vuforiaParams.cameraDirection = VuforiaLocalizer.CameraDirection.BACK;
        VuforiaLocalizer vuforia = ClassFactory.getInstance().createVuforia(vuforiaParams);
        FtcDashboard.getInstance().startCameraStream(vuforia, 0);
        int tfodMonitorViewId = hardwareMap.appContext.getResources().getIdentifier(
                "tfodMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        TFObjectDetector.Parameters tfodParameters = new TFObjectDetector.Parameters(tfodMonitorViewId);
        tfodParameters.minResultConfidence = 0.8f;
        tfod = ClassFactory.getInstance().createTFObjectDetector(tfodParameters, vuforia);
        tfod.loadModelFromAsset(TFOD_MODEL_ASSET, LABEL_FIRST_ELEMENT, LABEL_SECOND_ELEMENT);
    }
    public void AsteaptaStart() // pentru eroarea cu Motorola
    {
        while (!opModeIsActive() && !isStopRequested())
        {
            telemetry.update();
        }
    }

}
